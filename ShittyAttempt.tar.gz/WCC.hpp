#pragma once
#include "digraph.hpp"

class WeakCC
{
public:
    void DFSConnectedComponentUtil(const DiGraph& G, vector<int>& coloring, node_t v, int color);
    int num_connected_components(const DiGraph& G);
    vector<int> connected_components_coloring(const DiGraph& G);
    vector<vector<node_t>> connected_components(const DiGraph& G);
};