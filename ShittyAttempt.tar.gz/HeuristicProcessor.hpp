#pragma once

#include "digraph.hpp"

using ParamType = std::array<double, 8>;

class HeuristicProcessor
{
    HeuristicProcessor(DiGraph* D) : m_digraph(D) {}
    void set_parameters(const ParamType& new_params) 
    {
        m_params = new_params;
        heuristic_processing();
    }
    // This is the order in which the exneighbors are sorted
	inline bool ex_compare(node_t a, node_t b) const { return m_basic_topological_ordering_inverse[a] < m_basic_topological_ordering_inverse[b]; }

	// This is the order in which the exneighbors are sorted
	inline bool in_compare(node_t a, node_t b) const { return m_basic_topological_ordering_inverse_in[a] < m_basic_topological_ordering_inverse_in[b]; }
void remove_bad_nodes();
	void remove_nodes(const vector<node_t>& toRemove);
	void heuristic_processing();
	double get_heuristic_ex(node_t node);
	double get_heuristic_in(node_t node);
private:
    DiGraph* m_digraph;
    vector<double> m_heuristic_ex;
	vector<double> m_heuristic_in;
	
	vector<node_t> m_basic_topological_ordering;
	vector<node_t> m_basic_topological_ordering_in;
	vector<node_t> m_basic_topological_ordering_inverse;
	vector<node_t> m_basic_topological_ordering_inverse_in;
	
	
    vector<short> m_weak_coloring;
	vector<vector<node_t>> m_weakly_connected_components;
    
    ParamType m_params {{-43,31,11,58,-4,23,43,45}};
};

