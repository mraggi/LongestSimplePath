#pragma once
#include <vector>
#include <iostream>
#include <algorithm>
#include <set>
#include <unordered_set>
#include <stack>
#include "helpers.hpp"
#include "DiGraph.hpp"
#include "pseudotopoorder.hpp"

using namespace std;

struct SccInfo
{
	SccInfo(int s, int e, int c) : start(s), end(e), color(c) {}
	int start;
	int end;
	int color;
};

// Regresa el costo de llegar de a a cualquier otro nodo.
class StronglyConnectedComponents
{
public:
	StronglyConnectedComponents(const DiGraph& D) : m_digraph(D),m_strongly_connected_components(),m_scc_coloring(D.num_vertices()), m_scc_rank_out(),m_scc_rank_in() 
	{
		fill_strongly_connected_components();
        fill_rank(); // comment if not needed
	}
	
	const vector<vector<node_t>>& components() const { return m_strongly_connected_components; }
	const vector<node_t>& coloring() const { return m_scc_coloring; }
	const vector<node_t>& rank_out() const { return m_scc_rank_out; }
	const vector<node_t>& rank_in() const { return m_scc_rank_in; }
	size_t num_strongly_connected_components() const { return m_strongly_connected_components.size(); }
	bool is_strongly_connected() const { return num_strongly_connected_components() == 1; }
	bool is_acyclic() const { return num_strongly_connected_components() == m_digraph.num_vertices(); }
	int largest_component_color() const;
	// If it's acyclic, it's an actual topological sort
	vector<node_t> get_pseudo_topological_sort() const;
    inline const vector<SccInfo> big_scc() const { return m_scc_big_components; }
    PseudoTopoOrder get_random_pseudotopological_order() const;
private:
	void fill_strongly_connected_components();
    void fill_rank();
	void topo_fill_order(node_t v, vector<char>& visited, stack<node_t>& Stack); 
    void DFSUtilReversed(node_t v, vector<char>& visited, node_t current);
	
	const DiGraph& m_digraph;
	vector<vector<node_t>> m_strongly_connected_components;
	vector<node_t> m_scc_coloring;
	vector<node_t> m_scc_rank_out;
	vector<node_t> m_scc_rank_in;
    vector<SccInfo> m_scc_big_components;
};