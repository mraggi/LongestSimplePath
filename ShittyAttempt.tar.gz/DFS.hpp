#pragma once

#include "digraph.hpp
#include "path.hpp"

template <class Compare>
bool dfs_outnext(const DiGraph& G, Path& P, Compare comp)
{
    auto lastNode = P.back();
    
    auto Neighs = &G.outneighbors(lastNode);

    auto t = P.first_not_explored(*Neighs);

    while (t == INVALID_NODE && P.size() > 1) //this means all nodes in Neigh have been explored
    {
        lastNode = P.back();
        P.pop_back();
        int father = P.back();
        Neighs = &G.outneighbors(father);
        t = P.first_not_explored_binary(*Neighs,lastNode, comp);
    }
    if (t == INVALID_NODE)
        return false; // this means we have finished DFS!!
    P.push_back(t);
    return true;
}

template <class Compare>
bool dfs_innext(const DiGraph& G, Path& P, Compare comp)
{
    auto firstNode = P.front();
    
    auto Neighs = &G.inneighbors(firstNode);

    auto t = P.first_not_explored(*Neighs);

    while (t == INVALID_NODE && P.size() > 1) //this means all nodes in Neigh have been explored
    {
        firstNode = P.front();
        P.pop_front();
        int father = P.front();
        Neighs = &G.inneighbors(father);
        t = P.first_not_explored_binary(*Neighs,firstNode, comp);
    }
    if (t == INVALID_NODE)
        return false; // this means we have finished DFS!!
    P.push_front(t);
    return true;
}

inline bool dfs_outnext(const DiGraph& G, Path& P)
{
    return dfs_outnext(G,P,std::less<node_t>());
}

inline bool dfs_innext(const DiGraph& G, Path& P)
{
    return dfs_innext(G,P,std::less<node_t>());
}