#pragma once

class LongestSimplePathFinder
{
    		//Paths
	Path FindLongestSimplePath(double numseconds);
	Path FindLongestSimplePathPureDFS(double numseconds);
	void dfs_search_path_forward(Path& P, double maxnumseconds) const;
	void dfs_search_path_reverse(Path& P, double maxnumseconds) const;
	
	Path dfs_search_path_forward(node_t start, double maxnumseconds) const;
	Path dfs_search_path_reverse(node_t start, double maxnumseconds) const;

	Path dfs_search(double maxnumsecondswithoutimprovement) const;
    void pto_search(Path& A, double maxnumseconds) const;
};